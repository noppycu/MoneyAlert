package com.moneyalert

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.text.NumberFormat
import java.util.Locale
import java.util.regex.Pattern

class BankNotificationListener : NotificationListenerService() {
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var lastSpokenKey = ""
    private var lastSpokenAt = 0L

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val lang = tts?.setLanguage(Locale("th", "TH"))
                ttsReady = lang != TextToSpeech.LANG_MISSING_DATA && lang != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
        createChannel()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != KTB_PACKAGE) return
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val fullText = "$title $body".trim()
        if (fullText.isBlank() || !looksLikeCredit(fullText)) return

        val amount = extractAmount(fullText) ?: return
        val key = "${sbn.postTime}:$amount:$fullText"
        val now = System.currentTimeMillis()
        if (key == lastSpokenKey || (now - lastSpokenAt < 2500 && amount == lastSpokenKey.substringAfterLast(':'))) return
        lastSpokenKey = key
        lastSpokenAt = now

        val spoken = "แจ้งเตือน มีเงินเข้าจำนวน ${thaiAmount(amount)} บาท"
        if (ttsReady) tts?.speak(spoken, TextToSpeech.QUEUE_ADD, null, "credit-${sbn.id}-${sbn.postTime}")
        saveHistory(spoken)
        showLocalNotification(spoken)
    }

    private fun looksLikeCredit(text: String): Boolean {
        val s = text.lowercase(Locale.ROOT)
        val debitWords = listOf("เงินออก", "ถอนเงิน", "ชำระเงิน", "โอนเงินออก", "payment", "withdraw", "debited", "debit", "purchase")
        if (debitWords.any { s.contains(it) }) return false
        val creditWords = listOf("เงินเข้า", "ได้รับเงิน", "รับโอน", "เงินโอนเข้า", "โอนเงินเข้า", "ฝากเงิน", "credit", "credited", "received", "deposit")
        return creditWords.any { s.contains(it) }
    }

    private fun extractAmount(text: String): String? {
        // รองรับรูปแบบ 1,234.56 / 1234.56 / 1,234 บาท
        val p = Pattern.compile("(?<!\\d)(\\d{1,3}(?:,\\d{3})+(?:\\.\\d{1,2})?|\\d+(?:\\.\\d{1,2})?)\\s*(?:บาท|THB)?", Pattern.CASE_INSENSITIVE)
        val m = p.matcher(text)
        val values = mutableListOf<String>()
        while (m.find()) {
            val raw = m.group(1)?.replace(",", "") ?: continue
            if (raw.toDoubleOrNull() != null) values.add(raw)
        }
        // เลือกจำนวนเงินตัวแรกที่พบในข้อความแจ้งเตือน
        return values.firstOrNull()
    }

    private fun thaiAmount(raw: String): String {
        val value = raw.toDoubleOrNull() ?: return raw
        val nf = NumberFormat.getNumberInstance(Locale.US).apply { minimumFractionDigits = 0; maximumFractionDigits = 2 }
        return nf.format(value)
    }

    private fun saveHistory(line: String) {
        val prefs = getSharedPreferences("money_alert", Context.MODE_PRIVATE)
        val old = prefs.getString("history", "").orEmpty()
        prefs.edit().putString("history", (line + "\n" + old).take(4000)).apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("money_alert", "Money Alert", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun showLocalNotification(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "money_alert") else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Money Alert")
            .setContentText(message)
            .setAutoCancel(true)
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build())
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        // Package ID จากหน้า Google Play ของ Krungthai NEXT
        private const val KTB_PACKAGE = "ktbcs.netbank"
    }
}
