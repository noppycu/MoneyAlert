package com.moneyalert

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 48, 36, 36)
        }
        val title = TextView(this).apply {
            text = "Money Alert"
            textSize = 30f
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "แจ้งเตือนเงินเข้าจาก Krungthai NEXT"
            textSize = 17f
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 28)
        }
        status = TextView(this).apply {
            text = "สถานะ: ต้องอนุญาตการเข้าถึงการแจ้งเตือน"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 24)
        }
        val settingsButton = Button(this).apply {
            text = "เปิดการตั้งค่า Notification Access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val testButton = Button(this).apply {
            text = "ทดสอบเสียงภาษาไทย"
            setOnClickListener {
                val engine = tts
                if (engine != null) engine.speak("Money Alert ทดสอบเสียง มีเงินเข้าจำนวนหนึ่งพันห้าร้อยบาท", TextToSpeech.QUEUE_FLUSH, null, "money-alert-test")
            }
        }
        val note = TextView(this).apply {
            text = "วิธีใช้\n1. อนุญาต Notification Access ให้ Money Alert\n2. เปิดการแจ้งเตือนเงินเข้าของ Krungthai NEXT\n3. ทดสอบเสียง และปรับระดับเสียง Media\n\nแอปจะอ่านได้เฉพาะข้อมูลที่ธนาคารแสดงใน Notification"
            textSize = 15f
            setPadding(0, 28, 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(status)
        layout.addView(settingsButton)
        layout.addView(testButton)
        layout.addView(note)
        setContentView(layout)
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("th", "TH"))
            runOnUiThread {
                status.text = if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                    "สถานะ: เครื่องนี้ไม่มีเสียงภาษาไทย กรุณาติดตั้ง Thai TTS"
                else "สถานะ: พร้อมทดสอบเสียงภาษาไทย"
            }
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
