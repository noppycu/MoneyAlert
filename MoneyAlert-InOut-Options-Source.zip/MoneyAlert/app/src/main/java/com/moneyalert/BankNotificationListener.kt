package com.moneyalert

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.regex.Pattern

class BankNotificationListener : NotificationListenerService() {
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var pendingSpeech: String? = null
    private var lastSpokenKey = ""
    private var lastSpokenAt = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        record("Service เริ่มทำงาน", "", "")
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("th", "TH"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                tts?.setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build())
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) { log("TTS เริ่มเล่นเสียงอัตโนมัติ") }
                    override fun onDone(utteranceId: String?) { log("TTS เล่นเสียงจบแล้ว") }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { log("TTS เกิดข้อผิดพลาดขณะเล่นเสียง") }
                    override fun onError(utteranceId: String?, errorCode: Int) { log("TTS เล่นเสียงไม่สำเร็จ error=$errorCode") }
                })
                log(if (ttsReady) "TTS ภาษาไทยพร้อมใช้งาน" else "ไม่พบเสียงภาษาไทยในเครื่อง")
                if (ttsReady) pendingSpeech?.let { speak(it); pendingSpeech = null }
            } else log("เริ่มระบบ TTS ไม่สำเร็จ: $status")
        }
    }

    override fun onListenerConnected() { super.onListenerConnected(); log("Notification Listener เชื่อมต่อแล้ว") }
    override fun onListenerDisconnected() { super.onListenerDisconnected(); log("Notification Listener หลุดการเชื่อมต่อ") }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val text = collectNotificationText(sbn.notification)
        // Monitor the latest package/message for diagnostics; speak only for the configured bank package.
        if (sbn.packageName != KTB_PACKAGE) {
            record("ตรวจพบ Notification จากแอปอื่น (ไม่ประมวลผลเสียง)", sbn.packageName, text)
            return
        }
        if (text.isBlank()) {
            record("แจ้งเตือนจาก Krungthai NEXT ไม่มีข้อความให้อ่าน", sbn.packageName, "")
            return
        }
        record("ได้รับแจ้งเตือนจาก Krungthai NEXT", sbn.packageName, text)
        val transactionType = classifyTransaction(text)
        if (transactionType == TransactionType.UNKNOWN) { log("ข้าม: ไม่สามารถระบุได้ว่าเป็นเงินเข้าหรือเงินออก"); return }
        val selectedMode = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_ALERT_MODE, MODE_IN) ?: MODE_IN
        if (selectedMode == MODE_IN && transactionType != TransactionType.CREDIT) { log("ข้ามรายการเงินออก: ตั้งค่าแจ้งเตือนเฉพาะเงินเข้า"); return }
        if (selectedMode == MODE_OUT && transactionType != TransactionType.DEBIT) { log("ข้ามรายการเงินเข้า: ตั้งค่าแจ้งเตือนเฉพาะเงินออก"); return }
        val amount = extractAmount(text)
        if (amount == null) { log("พบรายการ${transactionType.label} แต่แยกยอดเงินไม่สำเร็จ"); return }
        saveAmount(amount, transactionType.label)
        val key = "${sbn.postTime}:$amount"
        val now = System.currentTimeMillis()
        if (key == lastSpokenKey || (now - lastSpokenAt < 2500 && amount == lastSpokenKey.substringAfter(':', ""))) {
            log("ข้ามการพูดซ้ำ: รายการซ้ำในช่วงเวลาสั้น"); return
        }
        lastSpokenKey = key; lastSpokenAt = now
        val spoken = if (transactionType == TransactionType.CREDIT) {
            "แจ้งเตือน มีเงินเข้าจำนวน ${thaiAmount(amount)} บาท"
        } else {
            "แจ้งเตือน มีเงินออกจำนวน ${thaiAmount(amount)} บาท"
        }
        if (ttsReady) speak(spoken) else { pendingSpeech = spoken; log("พบยอดเงิน $amount แต่รอ TTS พร้อมใช้งาน") }
        showLocalNotification(spoken)
    }

    private fun collectNotificationText(n: Notification): String {
        val e = n.extras ?: return ""
        val parts = mutableListOf<String>()
        listOf(Notification.EXTRA_TITLE, Notification.EXTRA_TEXT, Notification.EXTRA_BIG_TEXT, Notification.EXTRA_SUB_TEXT, Notification.EXTRA_SUMMARY_TEXT, Notification.EXTRA_INFO_TEXT).forEach { key ->
            e.getCharSequence(key)?.toString()?.takeIf { it.isNotBlank() }?.let(parts::add)
        }
        e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { it?.toString()?.let(parts::add) }
        return parts.distinct().joinToString(" ").trim()
    }

    private enum class TransactionType(val label: String) { CREDIT("เงินเข้า"), DEBIT("เงินออก"), UNKNOWN("ไม่ทราบประเภท") }

    private fun classifyTransaction(text: String): TransactionType {
        val s = text.lowercase(Locale.ROOT)
        val debit = listOf("เงินออก", "ถอนเงิน", "ถอนจาก", "ชำระเงิน", "โอนเงินออก", "โอนไปยัง", "จ่ายเงิน", "ตัดบัญชี", "ซื้อสินค้า", "payment", "withdraw", "debited", "debit", "purchase", "transferred to")
        val credit = listOf("เงินเข้า", "ได้รับเงิน", "รับเงิน", "รับโอน", "โอนเข้า", "ฝากเงิน", "ยอดเงินเข้า", "เครดิต", "credit", "credited", "received", "deposit", "transferred from")
        // Debit terms take priority to avoid reading a debit transaction as a credit.
        return when {
            debit.any(s::contains) -> TransactionType.DEBIT
            credit.any(s::contains) -> TransactionType.CREDIT
            else -> TransactionType.UNKNOWN
        }
    }

    private fun extractAmount(original: String): String? {
        val text = normalizeThaiDigits(original)
        val n = "([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]{1,2})?|[0-9]+(?:\\.[0-9]{1,2})?)"
        val patterns = listOf("(?:จำนวนเงิน|ยอดเงิน|amount|THB|บาท)\\s*[:：]?\\s*(?:฿\\s*)?$n", "(?:฿\\s*)?$n\\s*(?:บาท|THB)")
        for (pattern in patterns) Pattern.compile(pattern, Pattern.CASE_INSENSITIVE).matcher(text).let { if (it.find()) return it.group(1)?.replace(",", "") }
        return Pattern.compile("(?<![A-Za-z0-9])$n(?![A-Za-z0-9])").matcher(text).let { if (it.find()) it.group(1)?.replace(",", "") else null }
    }

    private fun normalizeThaiDigits(s: String): String {
        val digits = "๐๑๒๓๔๕๖๗๘๙"
        return buildString { s.forEach { c -> val i = digits.indexOf(c); append(if (i >= 0) ('0'.code + i).toChar() else c) } }
    }
    private fun thaiAmount(raw: String): String = raw.toDoubleOrNull()?.let { NumberFormat.getNumberInstance(Locale.US).apply { maximumFractionDigits = 2 }.format(it) } ?: raw
    private fun speak(message: String) {
        val engine = tts ?: run { pendingSpeech = message; return }
        if (!ttsReady) { pendingSpeech = message; return }
        // Use the media stream so notification-channel mute does not silence spoken alerts.
        engine.setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
            .build())
        val utteranceId = "money-alert-${System.currentTimeMillis()}"
        val result = engine.speak(message, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        log(if (result == TextToSpeech.SUCCESS) "ส่งคำสั่ง TTS สำเร็จ รอผลการเล่นเสียง" else "ส่งคำสั่ง TTS ไม่สำเร็จ result=$result")
    }
    private fun record(status: String, pkg: String, raw: String) {
        getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("last_status", status).putString("last_package", pkg.ifBlank { "-" }).putString("last_raw", raw.take(500)).putLong("last_event_at", System.currentTimeMillis()).apply()
        log(status + if (pkg.isNotBlank()) " [$pkg]" else "")
    }
    private fun saveAmount(amount: String, type: String) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("last_amount", amount).putString("last_transaction_type", type).apply()
        log("แยกยอด$typeสำเร็จ: $amount")
    }
    private fun log(message: String) {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        val line = "${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}  $message"
        val old = p.getString("debug_log", "").orEmpty().lines().filter { it.isNotBlank() }
        p.edit().putString("debug_log", (listOf(line) + old).take(10).joinToString("\n")).apply()
    }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("money_alert", "Money Alert", NotificationManager.IMPORTANCE_DEFAULT)) }
    private fun showLocalNotification(message: String) {
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, "money_alert") else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Money Alert").setContentText(message).setAutoCancel(true)
        getSystemService(NotificationManager::class.java).notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build())
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }
    companion object {
        private const val PREFS = "money_alert"
        private const val KTB_PACKAGE = "ktbcs.netbank"
        private const val KEY_ALERT_MODE = "alert_mode"
        private const val MODE_IN = "in"
        private const val MODE_OUT = "out"
        private const val MODE_BOTH = "both"
    }
}
