package com.moneyalert

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var dashboard: TextView
    private lateinit var logs: TextView
    private lateinit var ttsStatus: TextView
    private var ttsReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 24, 28, 24) }
        val scrollContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply { text = "🐷 MoneyAlert"; textSize = 28f; gravity = Gravity.CENTER; setPadding(0, 8, 0, 4) }
        val subtitle = TextView(this).apply { text = "ตรวจจับแจ้งเตือนเงินเข้า/ออกจาก Krungthai NEXT"; textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 0, 0, 18) }
        val modeTitle = sectionTitle("รูปแบบการแจ้งเตือน")
        val modeGroup = RadioGroup(this).apply {
            orientation = RadioGroup.VERTICAL
            val modes = listOf("in" to "แจ้งเตือนเงินเข้า", "out" to "แจ้งเตือนเงินออก", "both" to "แจ้งเตือนทั้งเงินเข้าและเงินออก")
            modes.forEach { (value, label) ->
                addView(RadioButton(this@MainActivity).apply { text = label; tag = value; id = View.generateViewId() })
            }
            val saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_ALERT_MODE, "in") ?: "in"
            for (i in 0 until childCount) {
                val child = getChildAt(i) as RadioButton
                if (child.tag == saved) { check(child.id); break }
            }
            setOnCheckedChangeListener { group, checkedId ->
                val selected = group.findViewById<RadioButton>(checkedId)?.tag as? String ?: "in"
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ALERT_MODE, selected).apply()
                appendLog("เปลี่ยนรูปแบบแจ้งเตือน: ${when (selected) { "in" -> "เงินเข้า"; "out" -> "เงินออก"; else -> "ทั้งเงินเข้าและเงินออก" }}")
                refreshDashboard()
            }
        }
        ttsStatus = TextView(this).apply { text = "TTS: กำลังตรวจสอบ"; textSize = 15f; setPadding(12, 12, 12, 12) }
        val access = Button(this).apply { text = "เปิดการตั้งค่า Notification Access"; setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }
        val test = Button(this).apply { text = "ทดสอบเสียงภาษาไทย"; setOnClickListener { testSpeech() } }
        val refresh = Button(this).apply { text = "รีเฟรช Dashboard"; setOnClickListener { refreshDashboard() } }
        val debugTitle = sectionTitle("Debug Dashboard")
        dashboard = TextView(this).apply { textSize = 14f; setPadding(14, 14, 14, 14); setBackgroundColor(0xFFEAF2FF.toInt()) }
        val logTitle = sectionTitle("Debug Log (ล่าสุด 10 รายการ)")
        logs = TextView(this).apply { textSize = 13f; setPadding(14, 14, 14, 14); setBackgroundColor(0xFFF2F4F7.toInt()) }
        val clear = Button(this).apply { text = "ล้าง Debug Log"; setOnClickListener { getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("debug_log", "").apply(); refreshDashboard() } }
        val note = TextView(this).apply { text = "หมายเหตุ: แอปอ่านข้อความจาก Notification ที่ Android ส่งให้เท่านั้น ไม่เชื่อมต่อบัญชีธนาคาร และไม่ใช่หลักฐานยืนยันธุรกรรม"; textSize = 13f; setPadding(0, 18, 0, 0) }
        listOf(title, subtitle, modeTitle, modeGroup, ttsStatus, access, test, refresh, debugTitle, dashboard, logTitle, logs, clear, note).forEach(scrollContent::addView)
        root.addView(ScrollView(this).apply { addView(scrollContent) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        refreshDashboard()
    }

    private fun sectionTitle(value: String) = TextView(this).apply { text = value; textSize = 19f; setPadding(0, 18, 0, 8) }

    private fun listenerEnabled(): Boolean {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: return false
        return enabled.split(":").any { ComponentName.unflattenFromString(it)?.packageName == packageName }
    }

    private fun refreshDashboard() {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        val stamp = p.getLong("last_event_at", 0L)
        val time = if (stamp > 0) SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date(stamp)) else "-"
        val pkg = p.getString("last_package", "-") ?: "-"
        val raw = p.getString("last_raw", "").orEmpty().ifBlank { "(ยังไม่มีข้อความ)" }
        val parsed = p.getString("last_amount", "-") ?: "-"
        val transactionType = p.getString("last_transaction_type", "-") ?: "-"
        val alertMode = when (p.getString(KEY_ALERT_MODE, "in")) { "out" -> "เงินออก"; "both" -> "เงินเข้าและเงินออก"; else -> "เงินเข้า" }
        val status = p.getString("last_status", "ยังไม่พบการแจ้งเตือน") ?: "ยังไม่พบการแจ้งเตือน"
        dashboard.text = "สถานะ Listener: ${if (listenerEnabled()) "เปิดใช้งาน" else "ยังไม่อนุญาต"}\n" +
            "รูปแบบแจ้งเตือน: $alertMode\nสถานะล่าสุด: $status\nเวลาที่ตรวจพบ: $time\nPackage: $pkg\nประเภทล่าสุด: $transactionType\nยอดเงินที่แยกได้: $parsed\n\nข้อความล่าสุด:\n$raw"
        logs.text = p.getString("debug_log", "ยังไม่มี Log") ?: "ยังไม่มี Log"
        ttsStatus.text = "TTS: ${if (ttsReady) "พร้อมใช้งาน" else "กำลังตรวจสอบ/ไม่พร้อม"}"
    }

    private fun testSpeech() {
        val engine = tts
        if (engine == null || !ttsReady) {
            appendLog("ทดสอบเสียงไม่สำเร็จ: TTS ยังไม่พร้อม")
            refreshDashboard()
            return
        }
        val result = engine.speak("Money Alert ทดสอบเสียงภาษาไทย มีเงินเข้าจำนวนหนึ่งพันห้าร้อยบาท", TextToSpeech.QUEUE_FLUSH, null, "money-alert-test")
        appendLog("ส่งคำสั่งทดสอบ TTS แล้ว ผล=$result")
        refreshDashboard()
    }

    private fun appendLog(message: String) {
        val p = getSharedPreferences(PREFS, MODE_PRIVATE)
        val line = "${SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())}  $message"
        val old = p.getString("debug_log", "").orEmpty().lines().filter { it.isNotBlank() }
        p.edit().putString("debug_log", (listOf(line) + old).take(10).joinToString("\n")).apply()
    }

    override fun onResume() { super.onResume(); refreshDashboard() }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val language = tts?.setLanguage(Locale("th", "TH"))
            ttsReady = language != TextToSpeech.LANG_MISSING_DATA && language != TextToSpeech.LANG_NOT_SUPPORTED
            appendLog(if (ttsReady) "TTS ภาษาไทยพร้อมใช้งาน" else "ไม่พบข้อมูลเสียงภาษาไทยในเครื่อง")
        } else appendLog("TTS initialization failed: $status")
        if (::ttsStatus.isInitialized) refreshDashboard()
    }
    override fun onDestroy() { tts?.stop(); tts?.shutdown(); super.onDestroy() }

    companion object { private const val PREFS = "money_alert"; private const val KEY_ALERT_MODE = "alert_mode" }
}
