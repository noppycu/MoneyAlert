package com.moneyalert

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import java.text.NumberFormat
import java.util.Locale
import java.util.regex.Pattern

class BankNotificationListener : NotificationListenerService() {
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    @Volatile private var pendingSpeech: String? = null
    private var lastSpokenKey = ""
    private var lastSpokenAt = 0L

    override fun onCreate() {
        super.onCreate()
        createChannel()
        setDiagnostic("กำลังเริ่มระบบอ่านข้อความ", "")
        tts = TextToSpeech(applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val result = tts?.setLanguage(Locale("th", "TH"))
                ttsReady = result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED
                setDiagnostic(if (ttsReady) "ระบบเสียงภาษาไทยพร้อมใช้งาน" else "ไม่พบเสียงภาษาไทยในเครื่อง", "")
                if (ttsReady) pendingSpeech?.let { speak(it); pendingSpeech = null }
            } else {
                setDiagnostic("เริ่มระบบเสียงไม่สำเร็จ (TTS init error)", "")
            }
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        setDiagnostic("เชื่อมต่อ Notification Access แล้ว รอแจ้งเตือนจาก Krungthai NEXT", "")
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName != KTB_PACKAGE) return
        val text = collectNotificationText(sbn.notification)
        if (text.isBlank()) {
            setDiagnostic("ได้รับแจ้งเตือนจาก Krungthai NEXT แต่ไม่มีข้อความให้อ่าน", "package=${sbn.packageName}")
            return
        }
        setDiagnostic("ได้รับแจ้งเตือนจาก Krungthai NEXT", text)

        if (!looksLikeCredit(text)) {
            setDiagnostic("พบแจ้งเตือนจากธนาคาร แต่ข้อความไม่เข้าข่ายเงินเข้า", text)
            return
        }
        val amount = extractAmount(text)
        if (amount == null) {
            setDiagnostic("พบข้อความคล้ายเงินเข้า แต่หา จำนวนเงิน ไม่พบ", text)
            return
        }

        val key = "${sbn.postTime}:$amount:$text"
        val now = System.currentTimeMillis()
        if (key == lastSpokenKey || (now - lastSpokenAt < 2500 && amount == lastSpokenKey.substringAfter(':').substringBefore(':'))) return
        lastSpokenKey = key
        lastSpokenAt = now

        val spoken = "แจ้งเตือน มีเงินเข้าจำนวน ${thaiAmount(amount)} บาท"
        if (ttsReady) speak(spoken) else {
            pendingSpeech = spoken
            setDiagnostic("ตรวจพบเงินเข้า ${thaiAmount(amount)} บาท แต่กำลังรอระบบเสียงภาษาไทย", text)
        }
        saveHistory(spoken)
        showLocalNotification(spoken)
    }

    private fun collectNotificationText(notification: Notification): String {
        val e = notification.extras ?: return ""
        val parts = mutableListOf<String>()
        listOf(Notification.EXTRA_TITLE, Notification.EXTRA_TEXT, Notification.EXTRA_BIG_TEXT,
            Notification.EXTRA_SUB_TEXT, Notification.EXTRA_SUMMARY_TEXT, Notification.EXTRA_INFO_TEXT)
            .forEach { key -> e.getCharSequence(key)?.toString()?.takeIf { it.isNotBlank() }?.let(parts::add) }
        e.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { it?.toString()?.let(parts::add) }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            e.getParcelableArray(Notification.EXTRA_MESSAGES)?.forEach { item ->
                if (item is android.os.Bundle) item.getCharSequence("text")?.toString()?.let(parts::add)
            }
        }
        return parts.distinct().joinToString(" ").trim()
    }

    private fun looksLikeCredit(text: String): Boolean {
        val s = text.lowercase(Locale.ROOT)
        val debitWords = listOf("เงินออก", "ถอนเงิน", "ชำระเงิน", "โอนเงินออก", "จ่ายเงิน", "payment", "withdraw", "debited", "debit", "purchase")
        if (debitWords.any { s.contains(it) }) return false
        val creditWords = listOf("เงินเข้า", "ได้รับเงิน", "รับเงิน", "รับโอน", "โอนเข้า", "เงินโอน", "ฝากเงิน", "ยอดเงินเข้า", "เครดิต", "credit", "credited", "received", "deposit")
        return creditWords.any { s.contains(it) }
    }

    private fun extractAmount(original: String): String? {
        val text = normalizeThaiDigits(original)
        val number = "([0-9]{1,3}(?:,[0-9]{3})*(?:\\.[0-9]{1,2})?|[0-9]+(?:\\.[0-9]{1,2})?)"
        val markedPatterns = listOf(
            "(?:จำนวนเงิน|ยอดเงิน|amount|THB|บาท)\\s*[:：]?\\s*(?:฿\\s*)?$number",
            "(?:฿\\s*)?$number\\s*(?:บาท|THB)"
        )
        for (pattern in markedPatterns) {
            val m = Pattern.compile(pattern, Pattern.CASE_INSENSITIVE).matcher(text)
            if (m.find()) return m.group(1)?.replace(",", "")
        }
        // Fallback: use the first numeric amount only after a credit phrase was detected.
        val m = Pattern.compile("(?<![A-Za-z0-9])$number(?![A-Za-z0-9])").matcher(text)
        return if (m.find()) m.group(1)?.replace(",", "") else null
    }

    private fun normalizeThaiDigits(s: String): String {
        val thai = "๐๑๒๓๔๕๖๗๘๙"
        return buildString { s.forEach { c -> val i = thai.indexOf(c); append(if (i >= 0) ('0'.code + i).toChar() else c) } }
    }

    private fun thaiAmount(raw: String): String {
        val value = raw.toDoubleOrNull() ?: return raw
        return NumberFormat.getNumberInstance(Locale.US).apply {
            minimumFractionDigits = 0
            maximumFractionDigits = 2
        }.format(value)
    }

    private fun speak(message: String) {
        val engine = tts
        if (engine == null || !ttsReady) { pendingSpeech = message; return }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            engine.setAudioAttributes(AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            engine.speak(message, TextToSpeech.QUEUE_ADD, null, "money-alert-${System.currentTimeMillis()}")
        } else {
            @Suppress("DEPRECATION")
            engine.speak(message, TextToSpeech.QUEUE_ADD, null)
        }
        setDiagnostic("อ่านข้อความแล้ว: $message", "")
    }

    private fun setDiagnostic(status: String, raw: String) {
        getSharedPreferences("money_alert", Context.MODE_PRIVATE).edit()
            .putString("last_status", status)
            .putString("last_raw", raw.take(1200))
            .putLong("last_event_at", System.currentTimeMillis())
            .apply()
    }

    private fun saveHistory(line: String) {
        val prefs = getSharedPreferences("money_alert", Context.MODE_PRIVATE)
        val old = prefs.getString("history", "").orEmpty()
        prefs.edit().putString("history", (line + "\n" + old).take(4000)).apply()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel("money_alert", "Money Alert", NotificationManager.IMPORTANCE_DEFAULT))
        }
    }

    private fun showLocalNotification(message: String) {
        val manager = getSystemService(NotificationManager::class.java)
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            Notification.Builder(this, "money_alert") else Notification.Builder(this)
        builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Money Alert")
            .setContentText(message)
            .setAutoCancel(true)
        manager.notify((System.currentTimeMillis() % Int.MAX_VALUE).toInt(), builder.build())
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val KTB_PACKAGE = "ktbcs.netbank"
    }
}
