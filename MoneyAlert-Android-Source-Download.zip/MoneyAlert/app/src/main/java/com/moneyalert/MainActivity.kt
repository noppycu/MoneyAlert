package com.moneyalert

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private lateinit var diagnostic: TextView
    private lateinit var voiceStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(36, 40, 36, 32)
        }
        val title = TextView(this).apply { text = "Money Alert"; textSize = 30f; gravity = Gravity.CENTER }
        val subtitle = TextView(this).apply {
            text = "แจ้งเตือนเงินเข้าจาก Krungthai NEXT"; textSize = 17f; gravity = Gravity.CENTER
            setPadding(0, 12, 0, 18)
        }
        voiceStatus = TextView(this).apply { text = "สถานะเสียง: กำลังตรวจสอบ"; textSize = 15f; gravity = Gravity.CENTER }
        val settingsButton = Button(this).apply {
            text = "เปิดการตั้งค่า Notification Access"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        }
        val testButton = Button(this).apply {
            text = "ทดสอบเสียงภาษาไทย"
            setOnClickListener {
                val engine = tts
                if (engine != null) engine.speak("Money Alert ทดสอบเสียง มีเงินเข้าจำนวนหนึ่งพันห้าร้อยบาท", TextToSpeech.QUEUE_FLUSH, null, "money-alert-test")
            }
        }
        val refreshButton = Button(this).apply {
            text = "รีเฟรชผลตรวจสอบล่าสุด"
            setOnClickListener { showDiagnostics() }
        }
        val diagnosticTitle = TextView(this).apply {
            text = "ผลตรวจสอบการแจ้งเตือน"; textSize = 18f; setPadding(0, 18, 0, 8)
        }
        diagnostic = TextView(this).apply {
            textSize = 14f
            setPadding(12, 12, 12, 12)
            text = "ยังไม่มีข้อมูลการแจ้งเตือน"
        }
        val note = TextView(this).apply {
            text = "วิธีใช้\n1. อนุญาต Notification Access ให้ Money Alert\n2. เปิดการแจ้งเตือนเงินเข้าของ Krungthai NEXT\n3. ทดสอบเสียงและปรับระดับเสียง Media\n4. เมื่อมีเงินเข้า ให้กลับมาดูผลตรวจสอบล่าสุดที่หน้านี้\n\nแอปอ่านข้อความจาก Notification เท่านั้น ไม่ได้เชื่อมต่อบัญชีธนาคาร"
            textSize = 14f; setPadding(0, 18, 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(voiceStatus)
        layout.addView(settingsButton)
        layout.addView(testButton)
        layout.addView(refreshButton)
        layout.addView(diagnosticTitle)
        layout.addView(diagnostic)
        layout.addView(note)
        val scroll = ScrollView(this).apply { addView(layout) }
        setContentView(scroll)
        showDiagnostics()
    }

    private fun showDiagnostics() {
        val p = getSharedPreferences("money_alert", MODE_PRIVATE)
        val status = p.getString("last_status", "ยังไม่มีการรับแจ้งเตือนจาก Krungthai NEXT")
        val raw = p.getString("last_raw", "").orEmpty()
        val at = p.getLong("last_event_at", 0L)
        val time = if (at > 0) SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date(at)) else "-"
        diagnostic.text = "สถานะ: $status\nเวลาล่าสุด: $time\n\nข้อความแจ้งเตือนที่ตรวจพบ:\n${if (raw.isBlank()) "(ไม่มีข้อความ)" else raw}"
    }

    override fun onResume() { super.onResume(); showDiagnostics() }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("th", "TH"))
            runOnUiThread {
                voiceStatus.text = if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED)
                    "สถานะเสียง: เครื่องนี้ไม่มีเสียงภาษาไทย กรุณาติดตั้ง Thai TTS"
                else "สถานะเสียง: พร้อมทดสอบภาษาไทย"
            }
        } else {
            voiceStatus.text = "สถานะเสียง: เริ่มระบบเสียงไม่สำเร็จ"
        }
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
